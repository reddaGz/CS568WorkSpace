import logo from "./logo.svg";
import "./App.css";
import React, { Component } from "react";
import Movie from "./Movie";

class App extends Component {
  state = {
    movies: [
      { id: 1, name: "Movie1", rating: 5, genre: "comedy" },
      { id: 2, name: "Movie2", rating: 5, genre: "Horror" },
    ],
  };
  deleteMovie = (id) => {
    const movies = this.state.movies.filter((elem) => elem.id !== id);
    this.setState({ movies });
  };
  changeMovieName = (id, event) => {
    let movies = this.state.movies.map((elem) => {
      if (elem.id === id) {
        let copy = { ...elem };
        copy.name = event.target.value;
        return copy;
      }
      return elem;
    });
    this.setState({ movies });
  };
  changeMovieRating = (id, event) => {
    let movies = this.state.movies.map((elem) => {
      if (elem.id === id) {
        let copy = { ...elem };
        copy.rating = event.target.value;
        return copy;
      }
      return elem;
    });
    this.setState({ movies });
  };
  changeMovieGenre = (id, event) => {
    let movies = this.state.movies.map((elem) => {
      if (elem.id === id) {
        let copy = { ...elem };
        copy.genre = event.target.value;
        return copy;
      }
      return elem;
    });
    this.setState({ movies });
  };
  updateMovie = (id, event) => {
    console.log(event.target.value);
  };
  render() {
    return (
      <div className="App">
        {this.state.movies.map((elem) => {
          return (
            <Movie
              key={elem.id}
              movieName={elem.name}
              movieRating={elem.rating}
              movieGenre={elem.genre}
              deleteMovie={() => this.deleteMovie(elem.id)}
              changeMovieName={(event)=>this.changeMovieName(elem.id,event)}
              changeMovieRating={(event)=>this.changeMovieRating(elem.id,event)}
              changeMovieGenre={(event)=>this.changeMovieGenre(elem.id,event)}
              updateMovie={() => this.updateMovie(elem.id)}
            ></Movie>
          );
        })}
      </div>
    );
  }
}

export default App;
