export default function Movie(props) {
  return (
    <div>
      <div>
        <div>{props.movieName}</div>
        <div>
          <input type="text" 
          value={props.movieName}
          onChange={props.changeMovieName} />
        </div>
        <div>{props.movieRating}</div>
        <div>
          <input type="text" value={props.movieRating}
          onChange={props.changeMovieRating} />
        </div>
        <div>{props.movieGenre}</div>
        <div>
          <input type="text" value={props.movieGenre} 
          onChange={props.changeMovieGenre} />
        </div>
        <button>Movie details</button>
        <button onClick={props.deleteMovie}>Delete</button>
        <button>update</button>
      </div>
    </div>
  );
}
